import os

idx = 0;
out = open("processed-5.txt", "w")
with open("test-5.txt") as file_:
	for line in file_:
		if idx ==10000:
			break;
		out.write(line)
		idx +=1
	print idx
	out.close()
